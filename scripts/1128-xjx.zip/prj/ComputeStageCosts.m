function G = ComputeStageCosts( stateSpace, map, myP)
%COMPUTESTAGECOSTS Compute stage costs.
% 	Compute the stage costs for all states in the state space for all
%   control inputs.
%
%   G = ComputeStageCosts(stateSpace, map)
%   computes the stage costs for all states in the state space for all
%   control inputs.
%
%   Input arguments:
%
%       stateSpace:
%           A (K x 3)-matrix, where the i-th row represents the i-th
%           element of the state space.
%
%       map:
%           A (M x N)-matrix describing the world. With
%           values: FREE TREE SHOOTER PICK_UP DROP_OFF BASE
%
%   Output arguments:
%
%       G:
%           A (K x L)-matrix containing the stage costs of all states in
%           the state space for all control inputs. The entry G(i, l)
%           represents the expected stage cost if we are in state i and
%           apply control input l.

global GAMMA R P_WIND Nc
global FREE TREE SHOOTER PICK_UP DROP_OFF BASE
global NORTH SOUTH EAST WEST HOVER
global K
global TERMINAL_STATE_INDEX
M =  size(map, 1);
N =  size(map, 2);
crash_P = zeros(M*N*2,M*N*2,5);
p_wind_dir = 0.25 * P_WIND;
p_windless = 1 - P_WIND;
%% to find the shooters' location in the map
[x_shooter,y_shooter] = find(map==SHOOTER);
shooter = [x_shooter,y_shooter];

%% to find the base' location in the map
[x_base, y_base] = find(map==BASE);
base = [x_base, y_base];
k_base = (base(1)-1)*2*N + base(2)*2 -1; % the loc of base corresponds to k_base in stateSpace, whose 3rd state is 0, no package
%% start the loop for initial state 2k and 2k-1, which are of the same location
for k = 1:0.5*M*N*2
    % to exclude the condition that state i resides in a TREE
    m1 = idivide(k-1,int16(N)) + 1;
    n1 = k - (m1 - 1)*N;
    if map(m1,n1) == TREE
        continue
    % in state i the drone stays at an not-TREE point on the map
    else
        for i = 1:5        
            % five different ctrl inputs
            switch i
                case 1
                    m0 = m1;
                    n0 = n1+1; % m0 and n0 are middle state after the control action
                case 2
                    m0 = m1;
                    n0 = n1-1;
                case 3
                    m0 = m1+1;
                    n0 = n1;
                case 4
                    m0 = m1-1;
                    n0 = n1;
                case 5
                    m0 = m1;
                    n0 = n1;
            end
            p = zeros(1,5); % a probability vector calculating the hover end up back in base
            
            % guarantee that the middle position is an inside-boundry not-TREE point
            if ((m0>=1 && m0<=M && n0>=1 && n0<=N) == 0) || map(m0,n0) == TREE
                continue
            else
                % next 6 possible positions on the map
                % j = (m0, n0+1, :), north in the second substep
                if n0 ~= N && map(m0, n0+1) ~= TREE
                    p_tri_miss = ComputeMissShotProb(shooter, m0, n0+1);
                    p(1) = p_wind_dir * (1 - p_tri_miss);
                else
                    p(1) = p_wind_dir;
                end
                
                % j = (m0, n0-1, :), south
                if n0 ~= 1 && map(m0, n0-1) ~= TREE
                    p_tri_miss = ComputeMissShotProb(shooter, m0, n0-1);
                    p(2) = p_wind_dir * (1 - p_tri_miss);
                else
                    p(2) = p_wind_dir;
                end
                
                % j = (m0+1, n0, :), east
                if m0 ~= M && map(m0+1, n0) ~= TREE
                    p_tri_miss = ComputeMissShotProb(shooter, m0+1, n0);
                    p(3) = p_wind_dir * (1 - p_tri_miss);
                else
                    p(3) = p_wind_dir;
                end
                
                % j = (m0-1, n0, :), west
                if m0 ~= 1 && map(m0-1, n0) ~= TREE
                    p_tri_miss = ComputeMissShotProb(shooter, m0-1, n0);
                    p(4) = p_wind_dir * (1 - p_tri_miss);
                else
                    p(4) = p_wind_dir;
                end
                
                % j = (m0, n0, :), stay, windless
                p_tri_miss = ComputeMissShotProb(shooter, m0, n0);
                p(5) = p_windless * (1 - p_tri_miss); 
                
                % j = (BASE_POSITION, 1), tree, out of boundry or shot; 
                % rev Nov.27 in this way, we include two end-up-base conditions:
                % crash back and non-crash back
                crash_P(2*k-1, k_base, i) = sum(p);
                crash_P(2*k, k_base, i) =sum(p);
            end
        end
    end
end
tree_index_k = [];
for m = 1 : M
    for n = 1 : N
        if map(m, n) == TREE
            tree_index_k = [tree_index_k, (m-1)*2*N+2*n-1, (m-1)*2*N+2*n];
        end
    end
end
crash_P(tree_index_k, :, :) =[];
crash_P(:, tree_index_k, :) =[];
G = zeros(K,5);
k_base_real = ComputeBaseStateIndex(stateSpace, map);
for k = 1:K/2
    % to exclude the condition that state i resides in a TREE
    m1 = stateSpace(2*k, 1);
    n1 = stateSpace(2*k, 2);
    % five different ctrl inputs
    for i = 1:5
        switch i
            case 1
                m0 = m1;
                n0 = n1+1; % m0 and n0 are middle state after the control action
            case 2
                m0 = m1;
                n0 = n1-1;
            case 3
                m0 = m1+1;
                n0 = n1;
            case 4
                m0 = m1-1;
                n0 = n1;
            case 5
                m0 = m1;
                n0 = n1;
        end
        
        % guarantee that the middle position is an inside-boundry not-TREE point
        if ((m0>=1 && m0<=M && n0>=1 && n0<=N) == 0) || map(m0,n0) == TREE
            G(2*k-1,i) = Inf;
            G(2*k,i) = Inf;
        % G(K, L) = 1 + 9*P(K, BASESTATE-NONPACKAGE, L)
        else
            G(2*k-1,i) = double(10*crash_P(2*k-1,k_base_real, i)+ myP(2*k-1,k_base_real, i)+...
                -crash_P(2*k-1,k_base_real, i)+(1 - myP(2*k-1,k_base_real, i)));
            G(2*k,i) = G(2*k-1,i);
        end
        
        if map(m1, n1) == DROP_OFF
            G(2*k,i) = 0;
        end
    end
end
end





















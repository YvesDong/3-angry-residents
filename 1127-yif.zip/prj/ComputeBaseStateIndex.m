function k_base_real = ComputeBaseStateIndex(stateSpace, map)
global BASE K
for x = 1:15
    for y = 1:20
        if map(x,y) == BASE
            base = [x,y];
            break
        end
    end
end
% the loc of base corresponds to k_base in stateSpace, whose 3rd state is 0, no package
for f = 1:K/2
    if stateSpace(2*f-1,1) == base(1) && stateSpace(2*f-1,2) == base(2)
        k_base_real = 2*f-1;
        break
    end
end
end